package com.example.app_miage_l3_2024;

import android.content.Intent;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ContactListActivity extends AppCompatActivity {

    private static final int CODE_REQUETE_AJOUT_ENTREPRISE = 1;
    private static final int CODE_REQUETE_IMAGE = 2;

    private TextView messageBienvenue;
    private RecyclerView vueRecycler;
    private EditText barreRecherche;
    private Button boutonAjouter;
    private EntrepriseAdapter adaptateur;
    private List<Entreprise> listeEntreprises;
    private Entreprise entreprisePourImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);

        messageBienvenue = findViewById(R.id.welcome_message);
        vueRecycler = findViewById(R.id.recyclerView);
        barreRecherche = findViewById(R.id.search_bar);
        boutonAjouter = findViewById(R.id.btnAdd);

        listeEntreprises = getIntent().getParcelableArrayListExtra("entreprises");
        if (listeEntreprises == null) {
            listeEntreprises = new ArrayList<>();
        }

        String login = getIntent().getStringExtra("login");
        messageBienvenue.setText("Bienvenue " + login);

        adaptateur = new EntrepriseAdapter(listeEntreprises, new EntrepriseAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Entreprise entreprise) {
                Intent intention = new Intent(ContactListActivity.this, AjoutEntrepriseActivity.class);
                intention.putExtra("entreprise", entreprise);
                startActivityForResult(intention, CODE_REQUETE_AJOUT_ENTREPRISE);
            }
        }, new EntrepriseAdapter.OnDeleteClickListener() {
            @Override
            public void onDeleteClick(Entreprise entreprise) {
                listeEntreprises.remove(entreprise);
                adaptateur.updateList(listeEntreprises);
                sauvegarderEntreprisesDansCSV();
            }
        }, new EntrepriseAdapter.OnAddImageClickListener() {
            @Override
            public void onAddImageClick(Entreprise entreprise) {
                entreprisePourImage = entreprise;
                Intent intentionImage = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intentionImage, CODE_REQUETE_IMAGE);
            }
        }, this);

        vueRecycler.setLayoutManager(new LinearLayoutManager(this));
        vueRecycler.setAdapter(adaptateur);

        barreRecherche.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filtrer(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        boutonAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intention = new Intent(ContactListActivity.this, AjoutEntrepriseActivity.class);
                startActivityForResult(intention, CODE_REQUETE_AJOUT_ENTREPRISE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CODE_REQUETE_AJOUT_ENTREPRISE && resultCode == RESULT_OK) {
            if (data != null) {
                if (data.hasExtra("supprimer")) {
                    Entreprise entrepriseASupprimer = data.getParcelableExtra("entreprise");
                    listeEntreprises.remove(entrepriseASupprimer);
                } else {
                    Entreprise nouvelleEntreprise = data.getParcelableExtra("entreprise");
                    if (nouvelleEntreprise != null && !listeEntreprises.contains(nouvelleEntreprise)) {
                        listeEntreprises.add(nouvelleEntreprise);
                    }
                }
                adaptateur.updateList(listeEntreprises);
                sauvegarderEntreprisesDansCSV();
            }
        } else if (requestCode == CODE_REQUETE_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            if (imageUri != null && entreprisePourImage != null) {
                entreprisePourImage.setImagePath(imageUri.toString());
                adaptateur.updateList(listeEntreprises);
                sauvegarderEntreprisesDansCSV();
            }
        }
    }

    private void filtrer(String texte) {
        List<Entreprise> listeFiltree = new ArrayList<>();
        for (Entreprise item : listeEntreprises) {
            if (item.getNom().toLowerCase().contains(texte.toLowerCase())) {
                listeFiltree.add(item);
            }
        }
        adaptateur.updateList(listeFiltree);
    }

    private void sauvegarderEntreprisesDansCSV() {
        try (FileOutputStream fos = openFileOutput("entreprises.csv", Context.MODE_PRIVATE)) {
            for (Entreprise entreprise : listeEntreprises) {
                String ligne = entreprise.getNom() + "," + entreprise.getAdresse() + "," + entreprise.getContact() + "," + entreprise.getImagePath() + "\n";
                fos.write(ligne.getBytes());
                Log.d("ContactListActivity", "Entreprise sauvegardée: " + entreprise.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("ContactListActivity", "Erreur lors de l'écriture dans le fichier entreprises.csv: " + e.getMessage());
        }
    }
}
