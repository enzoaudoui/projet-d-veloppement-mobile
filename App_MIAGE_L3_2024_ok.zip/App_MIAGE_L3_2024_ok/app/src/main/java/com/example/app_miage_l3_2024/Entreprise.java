package com.example.app_miage_l3_2024;

import android.os.Parcel;
import android.os.Parcelable;

public class Entreprise implements Parcelable {
    private String nom;
    private String adresse;
    private String contact;
    private String imagePath; // Nouveau champ

    public Entreprise() {}

    protected Entreprise(Parcel in) {
        nom = in.readString();
        adresse = in.readString();
        contact = in.readString();
        imagePath = in.readString(); // Lecture du chemin de l'image
    }

    public static final Creator<Entreprise> CREATOR = new Creator<Entreprise>() {
        @Override
        public Entreprise createFromParcel(Parcel in) {
            return new Entreprise(in);
        }

        @Override
        public Entreprise[] newArray(int size) {
            return new Entreprise[size];
        }
    };

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(nom);
        parcel.writeString(adresse);
        parcel.writeString(contact);
        parcel.writeString(imagePath); // Écriture du chemin de l'image
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Entreprise that = (Entreprise) o;

        if (!nom.equals(that.nom)) return false;
        if (!adresse.equals(that.adresse)) return false;
        return contact.equals(that.contact);
    }

    @Override
    public String toString() {
        return nom + " - " + adresse + " - " + contact;
    }
}
