package com.example.app_miage_l3_2024;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CreateUserActivity extends AppCompatActivity {

    private EditText champLogin, champMotDePasse;
    private Button boutonEnregistrerUtilisateur;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        champLogin = findViewById(R.id.editNewLogin);
        champMotDePasse = findViewById(R.id.editNewPassword);
        boutonEnregistrerUtilisateur = findViewById(R.id.btnCreateUser);

        boutonEnregistrerUtilisateur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = champLogin.getText().toString();
                String motDePasse = champMotDePasse.getText().toString();

                if (login.isEmpty() || motDePasse.isEmpty()) {
                    Toast.makeText(CreateUserActivity.this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
                } else {
                    enregistrerUtilisateur(login, motDePasse);
                    Toast.makeText(CreateUserActivity.this, "Utilisateur enregistré avec succès", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    private void enregistrerUtilisateur(String login, String motDePasse) {
        SharedPreferences preferences = getSharedPreferences("IdentifiantsUtilisateurs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(login, motDePasse);
        editor.apply();
    }
}
