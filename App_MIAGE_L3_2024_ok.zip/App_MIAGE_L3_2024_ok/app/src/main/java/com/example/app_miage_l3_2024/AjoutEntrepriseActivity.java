package com.example.app_miage_l3_2024;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AjoutEntrepriseActivity extends Activity {
    private EditText champNom, champAdresse, champContact;
    private Button boutonSauvegarder, boutonSupprimer;
    private Entreprise entreprise;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_entreprise);

        champNom = findViewById(R.id.editNom);
        champAdresse = findViewById(R.id.editAdresse);
        champContact = findViewById(R.id.editContact);
        boutonSauvegarder = findViewById(R.id.btnSave);
        boutonSupprimer = findViewById(R.id.btnDelete);

        Intent intention = getIntent();
        if (intention.hasExtra("entreprise")) {
            entreprise = intention.getParcelableExtra("entreprise");
            if (entreprise != null) {
                champNom.setText(entreprise.getNom());
                champAdresse.setText(entreprise.getAdresse());
                champContact.setText(entreprise.getContact());
            }
        } else {
            entreprise = new Entreprise();
        }

        boutonSauvegarder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                entreprise.setNom(champNom.getText().toString());
                entreprise.setAdresse(champAdresse.getText().toString());
                entreprise.setContact(champContact.getText().toString());

                Intent resultatIntention = new Intent();
                resultatIntention.putExtra("entreprise", entreprise);
                setResult(Activity.RESULT_OK, resultatIntention);
                finish();
            }
        });

        boutonSupprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultatIntention = new Intent();
                resultatIntention.putExtra("supprimer", true);
                resultatIntention.putExtra("entreprise", entreprise);
                setResult(Activity.RESULT_OK, resultatIntention);
                finish();
            }
        });
    }
}
