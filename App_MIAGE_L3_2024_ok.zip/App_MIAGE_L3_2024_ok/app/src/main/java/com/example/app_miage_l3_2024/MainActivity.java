package com.example.app_miage_l3_2024;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private EditText champLogin, champMotDePasse;
    private Button boutonConnexion, boutonCreerUtilisateur;
    private ArrayList<Entreprise> listeEntreprises;
    private Map<String, String> identifiantsUtilisateurs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        verifierPermissions();

        champLogin = findViewById(R.id.editLogin);
        champMotDePasse = findViewById(R.id.editPassword);
        boutonConnexion = findViewById(R.id.btnLogin);
        boutonCreerUtilisateur = findViewById(R.id.btnCreateUser);

        listeEntreprises = new ArrayList<>();
        identifiantsUtilisateurs = new HashMap<>();

        // Charger les utilisateurs existants
        chargerIdentifiantsUtilisateurs();

        // Charger les entreprises depuis le CSV
        chargerEntreprisesDepuisCSV();

        boutonConnexion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login = champLogin.getText().toString();
                String motDePasse = champMotDePasse.getText().toString();

                if (validerConnexion(login, motDePasse)) {
                    Intent intention = new Intent(MainActivity.this, ContactListActivity.class);
                    intention.putParcelableArrayListExtra("entreprises", listeEntreprises);
                    intention.putExtra("login", login);
                    startActivity(intention);
                } else {
                    Toast.makeText(MainActivity.this, "Login ou mot de passe incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

        boutonCreerUtilisateur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intention = new Intent(MainActivity.this, CreateUserActivity.class);
                startActivity(intention);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Recharger les identifiants des utilisateurs au cas où un nouvel utilisateur a été ajouté
        chargerIdentifiantsUtilisateurs();
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Sauvegarder les entreprises dans le CSV
        sauvegarderEntreprisesDansCSV();
    }

    private boolean validerConnexion(String login, String motDePasse) {
        return identifiantsUtilisateurs.containsKey(login) && identifiantsUtilisateurs.get(login).equals(motDePasse);
    }

    private void chargerIdentifiantsUtilisateurs() {
        SharedPreferences preferences = getSharedPreferences("IdentifiantsUtilisateurs", Context.MODE_PRIVATE);
        identifiantsUtilisateurs.clear();
        Map<String, ?> toutesLesEntrees = preferences.getAll();
        for (Map.Entry<String, ?> entree : toutesLesEntrees.entrySet()) {
            identifiantsUtilisateurs.put(entree.getKey(), entree.getValue().toString());
        }
    }

    private void chargerEntreprisesDepuisCSV() {
        listeEntreprises.clear(); // Vider la liste pour éviter les doublons
        try (FileInputStream fis = openFileInput("entreprises.csv");
             BufferedReader reader = new BufferedReader(new InputStreamReader(fis))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                String[] parts = ligne.split(",");
                if (parts.length == 3) {
                    Entreprise entreprise = new Entreprise();
                    entreprise.setNom(parts[0]);
                    entreprise.setAdresse(parts[1]);
                    entreprise.setContact(parts[2]);
                    listeEntreprises.add(entreprise);
                    Log.d("MainActivity", "Entreprise chargée: " + entreprise.toString());
                } else {
                    Log.e("MainActivity", "Format CSV incorrect: " + ligne);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("MainActivity", "Erreur lors de la lecture du fichier entreprises.csv: " + e.getMessage());
        }
    }

    private void sauvegarderEntreprisesDansCSV() {
        try (FileOutputStream fos = openFileOutput("entreprises.csv", Context.MODE_PRIVATE)) {
            for (Entreprise entreprise : listeEntreprises) {
                String ligne = entreprise.getNom() + "," + entreprise.getAdresse() + "," + entreprise.getContact() + "\n";
                fos.write(ligne.getBytes());
                Log.d("MainActivity", "Entreprise sauvegardée: " + entreprise.toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("MainActivity", "Erreur lors de l'écriture dans le fichier entreprises.csv: " + e.getMessage());
        }
    }

    private void verifierPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ||
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                }, 1);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission accordée", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission refusée", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
