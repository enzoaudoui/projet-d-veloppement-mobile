package com.example.app_miage_l3_2024;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EntrepriseAdapter extends RecyclerView.Adapter<EntrepriseAdapter.ViewHolder> {

    private List<Entreprise> entreprises;
    private OnItemClickListener listener;
    private OnDeleteClickListener deleteListener;
    private OnAddImageClickListener addImageListener;
    private Context context;

    public interface OnItemClickListener {
        void onItemClick(Entreprise entreprise);
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Entreprise entreprise);
    }

    public interface OnAddImageClickListener {
        void onAddImageClick(Entreprise entreprise);
    }

    public EntrepriseAdapter(List<Entreprise> entreprises, OnItemClickListener listener, OnDeleteClickListener deleteListener, OnAddImageClickListener addImageListener, Context context) {
        this.entreprises = entreprises;
        this.listener = listener;
        this.deleteListener = deleteListener;
        this.addImageListener = addImageListener;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_entreprise, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Entreprise entreprise = entreprises.get(position);
        holder.nomTextView.setText("Nom: " + entreprise.getNom());
        holder.adresseTextView.setText("Adresse: " + entreprise.getAdresse());
        holder.contactTextView.setText("Contact: " + entreprise.getContact());

        if (entreprise.getImagePath() != null && !entreprise.getImagePath().isEmpty()) {
            holder.imageView.setVisibility(View.VISIBLE);
            holder.imageView.setImageURI(Uri.parse(entreprise.getImagePath()));
        } else {
            holder.imageView.setVisibility(View.GONE);
        }

        holder.addImageButton.setOnClickListener(v -> addImageListener.onAddImageClick(entreprise));
        holder.deleteButton.setOnClickListener(v -> deleteListener.onDeleteClick(entreprise));
        holder.itemView.setOnClickListener(v -> listener.onItemClick(entreprise));
    }

    @Override
    public int getItemCount() {
        return entreprises.size();
    }

    public void updateList(List<Entreprise> newList) {
        entreprises = newList;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView nomTextView;
        public TextView adresseTextView;
        public TextView contactTextView;
        public ImageView imageView;
        public Button addImageButton;
        public Button deleteButton;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nomTextView = itemView.findViewById(R.id.text1);
            adresseTextView = itemView.findViewById(R.id.text2);
            contactTextView = itemView.findViewById(R.id.text3);
            imageView = itemView.findViewById(R.id.imageView);
            addImageButton = itemView.findViewById(R.id.btnAddImage);
            deleteButton = itemView.findViewById(R.id.btnDelete);
        }
    }
}
